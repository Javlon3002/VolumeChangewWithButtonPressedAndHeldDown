package com.example.volumechange;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btnUp;
    private Button btnDown;
    private TextView txtProgress;
    private SeekBar seekBar;

    private boolean upIsPressed = false;
    private boolean downIsPressed = false;

    int progress;

    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnUp = findViewById(R.id.btnUp);
        btnDown = findViewById(R.id.btnDown);

        seekBar = findViewById(R.id.seekBar);
        txtProgress = findViewById(R.id.txtProgress);

        txtProgress.setText(Integer.toString(progress));

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
                txtProgress.setText(Integer.toString(i));
                progress = i;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        btnUp.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        upIsPressed = true;
                        handler.post(runnable);
                        break;

                    case MotionEvent.ACTION_UP:
                        upIsPressed = false;
                        break;
                }
                return false;
            }
        });


        btnDown.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downIsPressed = true;
                        handler.post(runnable);
                        break;

                    case MotionEvent.ACTION_UP:
                        downIsPressed = false;
                        break;
                }
                return false;
            }
        });


    }


    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            if (upIsPressed) {
                if (progress < seekBar.getMax()) {
                    progress++;
                    seekBar.setProgress(progress);
                    handler.postDelayed(this, 50);
                }
            }


            if (downIsPressed) {
                if (progress > 0) {
                    progress--;
                    seekBar.setProgress(progress);
                    handler.postDelayed(this, 50);
                }
            }


        }
    };


}